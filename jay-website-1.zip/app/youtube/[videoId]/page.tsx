import { EmbeddedYoutube } from "@/components/embedded-youtube"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { fetchYoutubeVideos } from "@/lib/youtube"
import { formatDate } from "@/lib/utils"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

interface VideoPageProps {
  params: {
    videoId: string
  }
}

export default async function VideoPage({ params }: VideoPageProps) {
  const { videoId } = params
  const videos = await fetchYoutubeVideos(10)
  const video = videos.find((v) => v.id === videoId)

  if (!video) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Video nicht gefunden</h1>
        <Button asChild>
          <Link href="/youtube">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Zurück zu allen Videos
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Button asChild variant="outline" className="mb-6">
        <Link href="/youtube">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Zurück zu allen Videos
        </Link>
      </Button>

      <Card className="overflow-hidden mb-6">
        <EmbeddedYoutube videoId={videoId} title={video.title} />
      </Card>

      <h1 className="text-2xl font-bold mb-2">{video.title}</h1>
      <p className="text-muted-foreground mb-8">Veröffentlicht am {formatDate(video.publishedAt)}</p>

      <h2 className="text-xl font-semibold mb-4">Weitere Videos</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {videos
          .filter((v) => v.id !== videoId)
          .slice(0, 3)
          .map((relatedVideo) => (
            <Link key={relatedVideo.id} href={`/youtube/${relatedVideo.id}`}>
              <Card className="overflow-hidden hover:ring-2 hover:ring-primary transition-all">
                <div className="relative aspect-video">
                  <img
                    src={relatedVideo.thumbnail || "/placeholder.svg"}
                    alt={relatedVideo.title}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-medium line-clamp-2">{relatedVideo.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">{formatDate(relatedVideo.publishedAt)}</p>
                </div>
              </Card>
            </Link>
          ))}
      </div>
    </div>
  )
}
