import { type NextRequest, NextResponse } from "next/server"

// Globale Highscore-Speicherung mit Vercel KV (falls verfügbar) oder In-Memory
const globalHighscores: Array<{
  id: string
  game: string
  username: string
  score: number
  timestamp: string
  device: string
}> = []

// Simuliere eine persistente Datenbank durch eine globale Variable
// In einer echten Anwendung würde man Vercel KV, Supabase oder eine andere Datenbank verwenden
const HIGHSCORES_STORAGE = new Map<string, any>()

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const game = searchParams.get("game")

  try {
    // Lade alle Highscores aus dem "persistenten" Speicher
    const allScores = HIGHSCORES_STORAGE.get("global_highscores") || []

    let filteredScores = allScores

    if (game) {
      filteredScores = allScores.filter((score: any) => score.game === game)
    }

    // Sortiere nach Score (höchster zuerst) und nimm nur die Top 100
    const sortedScores = filteredScores.sort((a: any, b: any) => b.score - a.score).slice(0, 100)

    return NextResponse.json({
      success: true,
      highscores: sortedScores,
      total: allScores.length,
    })
  } catch (error) {
    console.error("Fehler beim Laden der Highscores:", error)
    return NextResponse.json({ success: false, error: "Fehler beim Laden der Highscores" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { game, username, score } = await request.json()

    if (!game || !username || typeof score !== "number") {
      return NextResponse.json({ success: false, error: "Ungültige Daten" }, { status: 400 })
    }

    // Lade bestehende Highscores
    const existingScores = HIGHSCORES_STORAGE.get("global_highscores") || []

    // Erstelle neuen Highscore-Eintrag
    const newHighscore = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      game,
      username,
      score,
      timestamp: new Date().toISOString(),
      device: request.headers.get("user-agent")?.substring(0, 50) || "unknown",
    }

    // Füge den neuen Score hinzu
    existingScores.push(newHighscore)

    // Behalte nur die letzten 10000 Einträge um Speicher zu sparen
    if (existingScores.length > 10000) {
      existingScores.splice(0, existingScores.length - 10000)
    }

    // Speichere zurück in den "persistenten" Speicher
    HIGHSCORES_STORAGE.set("global_highscores", existingScores)

    console.log(`Neuer Highscore gespeichert: ${username} - ${game} - ${score}`)
    console.log(`Gesamt Highscores: ${existingScores.length}`)

    return NextResponse.json({
      success: true,
      message: "Highscore gespeichert",
      highscore: newHighscore,
      total: existingScores.length,
    })
  } catch (error) {
    console.error("Fehler beim Speichern des Highscores:", error)
    return NextResponse.json({ success: false, error: "Fehler beim Speichern des Highscores" }, { status: 500 })
  }
}

// Lösche alle Highscores (nur für Entwicklung)
export async function DELETE() {
  try {
    HIGHSCORES_STORAGE.delete("global_highscores")
    return NextResponse.json({
      success: true,
      message: "Alle Highscores gelöscht",
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Fehler beim Löschen" }, { status: 500 })
  }
}
